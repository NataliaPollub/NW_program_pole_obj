# mathrix

mathrix to program do obliczania pola prostokąta i objętości prostopadłościanu.
Wystarczy podać odpowiednie długości boków i wysokość.


## Wersja
Version 1.0 - standard.


## Instalacja - najprostszy sposób
Należy wykonać poniższe kroki:
 1. Wejdź do katologu z programem.
 2. Wpisz: ./configure
 3. Wpisz: make
 4. Wpisz: mathrix

Aby dokonać bardziej zaawansowanej instalacji zobacz plik INSTALL

## Sposób działania programu
Po uruchomieniu program poprosi nas o podanie długości 2 boków oraz wysokosci.
Program obliczy za nas pole powierzchni prostokąta i objętość.
