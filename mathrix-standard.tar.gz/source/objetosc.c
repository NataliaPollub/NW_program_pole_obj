#include "objetosc.h"

void objetosc(float b1, float b2, float h)
{
    printf("\nProstopadloscian o wymiarach: %.2f x %.2f x %.2f\n", b1, b2, h);
    printf("Objetosc prostopadloscianu: %.2f\n", b1*b2*h);
}
