#include "pole.h"

void pole(float b1, float b2)
{
    printf("\nProstokat o wymiarach: %.2f x %.2f\n", b1, b2);
    printf("Pole prostokata wynosi: %.2f\n", b1*b2);
}
