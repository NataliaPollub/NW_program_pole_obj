#ifndef pole_h
#define pole_h

void pole(float b1, float b2);

#endif // pole_h
