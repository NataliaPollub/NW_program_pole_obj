#ifndef objetosc_h
#define objetosc_h

void objetosc(float b1, float b2, float h);

#endif // objetosc_h
